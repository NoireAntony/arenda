<?php

?>
<header>

    <div class="container"style="width: 1200px;background-color:green;">
        <div class="row">
         <div class="col-lg-6">
            <div class="head-item logo">
              <img src="img/logo.png" class="img-fluid"style="width: 50px;height: 60px;padding-top: 15px; padding-right: 7px; padding-bottom:9px;">
           
             
</div>
</div>
<div class="col-lg-6" style="display:flex; flex-direction:row; ">
        

        
        <a class="nav-link active" aria-current="page" href="index.php"style="color:white">ГЛАВНАЯ</a>
      </li>

 
     
    
     
    
    

        <a class="nav-link" href ="autorization.php"style="color:white">Войти</a>
      </li>

   

 
      
      </div>   
</div>
</div>     
      
     </header>